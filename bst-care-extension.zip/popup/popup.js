document.addEventListener('DOMContentLoaded', () => {
  const globalToggle = document.getElementById('globalToggle');
  const themeToggle = document.getElementById('themeToggle');
  const sitesTextarea = document.getElementById('sitesTextarea');
  const phrasesList = document.getElementById('phrasesList');
  const currentSiteDiv = document.getElementById('currentSite');
  const addPhraseBtn = document.getElementById('addPhraseBtn');

  let currentHost = "";

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    try {
      const url = new URL(tabs[0].url);
      currentHost = url.hostname.replace(/^www\./, '');
      currentSiteDiv.textContent = currentHost;
      loadSettings();
    } catch (e) {
      currentSiteDiv.textContent = "Unable to determine site";
    }
  });

  function loadSettings() {
    chrome.storage.sync.get({
      enabled: true,
      sites: ["app.intercom.com"],
      phrases: [],
      darkTheme: true
    }, data => {
      globalToggle.checked = data.enabled;
      themeToggle.checked = data.darkTheme;
      applyTheme(data.darkTheme);
      sitesTextarea.value = data.sites.join('\n');
      renderPhrases(data.phrases || []);
    });
  }

  function applyTheme(isDark) {
    document.body.classList.toggle('dark-theme', isDark);
    document.body.classList.toggle('light-theme', !isDark);
  }

  function renderPhrases(phrases) {
    phrasesList.innerHTML = '';
    
    phrases.forEach((phrase, index) => {
      const phraseContainer = createPhraseContainer(phrase.find, phrase.replacements || [], index);
      phrasesList.appendChild(phraseContainer);
    });
    
    addPhraseBtn.style.display = 'block';
  }

  function createPhraseContainer(findValue, replacements, index) {
  const container = document.createElement('div');
  container.className = 'phrase-container';
  
  // Phrase to find section
  const phraseLabel = document.createElement('div');
  phraseLabel.className = 'phrase-input-label';
  phraseLabel.textContent = 'Phrase to find:';
  container.appendChild(phraseLabel);
  
  const header = document.createElement('div');
  header.className = 'phrase-header';
  
  const phraseInput = document.createElement('input');
  phraseInput.type = 'text';
  phraseInput.className = 'phrase-input';
  phraseInput.placeholder = 'Enter phrase to highlight...';
  phraseInput.value = findValue;
  
  const removePhraseBtn = document.createElement('button');
  removePhraseBtn.className = 'remove-phrase-btn';
  removePhraseBtn.textContent = 'Remove phrase';
  removePhraseBtn.addEventListener('click', () => {
    container.remove();
    savePhrases();
  });
  
  header.appendChild(phraseInput);
  header.appendChild(removePhraseBtn);
  container.appendChild(header);
  
  // Separator
  const separator = document.createElement('hr');
  separator.className = 'phrase-separator';
  container.appendChild(separator);
  
  // Replacements section
  const replacementsLabel = document.createElement('div');
  replacementsLabel.className = 'replacements-label';
  replacementsLabel.textContent = 'Replacement options:';
  container.appendChild(replacementsLabel);
  
  const replacementsList = document.createElement('div');
  replacementsList.className = 'replacements-list';
  
  replacements.forEach((replacement, repIndex) => {
    const replacementItem = createReplacementItem(replacement);
    replacementsList.appendChild(replacementItem);
  });
  
  const addReplacementBtn = document.createElement('button');
  addReplacementBtn.className = 'add-replacement-btn';
  addReplacementBtn.textContent = '+ Add replacement option';
  addReplacementBtn.addEventListener('click', () => {
    const newItem = createReplacementItem('');
    replacementsList.appendChild(newItem);
  });
  
  container.appendChild(replacementsList);
  container.appendChild(addReplacementBtn);
  
  // Save on changes
  phraseInput.addEventListener('input', debounce(savePhrases, 300));
  replacementsList.addEventListener('input', debounce(savePhrases, 300));
  
  return container;
}

  function createReplacementItem(value) {
    const item = document.createElement('div');
    item.className = 'replacement-item';
    
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'replacement-input';
    input.placeholder = 'Replacement text';
    input.value = value;
    
    const removeBtn = document.createElement('button');
    removeBtn.className = 'remove-replacement-btn';
    removeBtn.textContent = '✕';
    removeBtn.addEventListener('click', () => {
      item.remove();
      savePhrases();
    });
    
    item.appendChild(input);
    item.appendChild(removeBtn);
    
    return item;
  }

  function savePhrases() {
    const phrases = [];
    
    document.querySelectorAll('.phrase-container').forEach(container => {
      const phraseInput = container.querySelector('.phrase-input');
      const phrase = phraseInput.value.trim();
      
      if (phrase) {
        const replacements = [];
        container.querySelectorAll('.replacement-input').forEach(input => {
          const replacement = input.value.trim();
          if (replacement) {
            replacements.push(replacement);
          }
        });
        
        phrases.push({
          find: phrase,
          replacements: replacements
        });
      }
    });
    
    chrome.storage.sync.set({ phrases });
  }
  addPhraseBtn.addEventListener('click', () => {
    const newPhraseContainer = createPhraseContainer('', ['']);
    phrasesList.appendChild(newPhraseContainer);
    newPhraseContainer.querySelector('.phrase-input').focus();
  });

  function debounce(func, wait) {
    let timeout;
    return function() {
      const context = this, args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        func.apply(context, args);
      }, wait);
    };
  }

  globalToggle.addEventListener('change', () => {
    chrome.storage.sync.set({ enabled: globalToggle.checked });
  });

  themeToggle.addEventListener('change', () => {
    const dark = themeToggle.checked;
    chrome.storage.sync.set({ darkTheme: dark });
    applyTheme(dark);
  });

  sitesTextarea.addEventListener('blur', () => {
    const sites = sitesTextarea.value
      .split(/\r?\n/)
      .map(s => s.trim().replace(/^https?:\/\//, '').replace(/^www\./, ''))
      .filter(Boolean);
    chrome.storage.sync.set({ sites });
  });
});